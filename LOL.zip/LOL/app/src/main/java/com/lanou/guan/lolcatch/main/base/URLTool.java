package com.lanou.guan.lolcatch.main.base;

/**
 * Created by dllo on 16/5/14.
 */
public class URLTool {
    public final static String INFORMATION_NEWEST = "http://lol.zhangyoubao.com/mobiles/item/53948?user_id=&token=&i_=EAC1B788-00BC-454A-A9B9-460852CFC011&t_=1438745542&p_=18971&v_=40050303&d_=ios&osv_=8.3&version=0&a_=lol&size=middle";
    public final static String INFORMATION_IMAGE_FIRST = "http://avatar.anzogame.com/pic_v1/lol/news/20160512/picad65631h5733f9d2.jpg";
    public final static String INFORMATION_IMAGE_SECOND = "http://avatar.anzogame.com/pic_v1/lol/news/20160509/picad65506h573031f7.jpg";
    public final static String INFORMATION_IMAGE_THIRD = "http://avatar.anzogame.com/pic_v1/lol/news/20160504/picad65250h5729a7ea.jpg";
}
