package com.lanou.guan.lolcatch.main.base;

import java.util.List;

/**
 * Created by dllo on 16/5/14.
 */
public class Bean {

    /**
     * data : [{"id":"65721","title":"【直播】CLG 2:1 闪电狼","desc":"MSI季中赛半决赛今日13:30起","video_url":"http://qqlive.dnion.com:1863/125304401.flv?cdncode=%2f18907E7BE0798990%2f&time=1463201755&cdn=zijian&sdtfrom=v220222&platform=10202&scheduleflag=1&buname=qqlive&vkey=DAC6880BCCC4C2FDCB784445B2CDE1AC022213B823DAC8A19A0AC0D94E860A0D0B45A9C6396B397355ECAB5B1D5FE0E6267522BCF9CA62103331B999F12A2BE9AC5C3DAAEC309A48D8356659F4289E7E464BBF3645FBD850","published":1463197821,"weight_new":"999","platform":"1","pic_url":"http://avatar.anzogame.com/pic_v1/lol/news/20160514/spic65721h5736b004.jpg","recommend":1},{"id":"65729","title":"【战报】CLG顶住压力拿到赛点","desc":"季中邀请赛半决赛CLG vs FW第三场：CLG顶住压力拿到赛点","video_url":"","published":1463214798,"weight_new":"0","platform":"1","pic_url":"","recommend":0},{"id":"65728","title":"半决赛CLG vs FW 第2场","desc":"2016MSI季中冠军赛半决赛 第2日","video_url":"http://video.dispatch.tc.qq.com/c0199ghqy89.mp4?vkey=C1664FB6EB2E3304E3687EE787DB507EE741ED98E444E10B5F9DB3D8AECDE178D0D7C66104C643DB4E4FF52B0E5E1B784797B6FDA6764722B925B942EFB0E2E4E78B1D07F784B1B13309BCE2E14083F97B6B0FD0B1AA4DDA&br=60&platform=2&fmt=auto&level=0&sdtfrom=v5010","published":1463213905,"weight_new":"0","platform":"1","pic_url":"http://avatar.anzogame.com/pic_v1/lol/news/20160514/spic65728h5736dfe9.jpg","recommend":0},{"id":"65727","title":"夕阳采访：CLG的沙皇和我55开","desc":"圣枪哥为RNG感到惋惜","video_url":"http://video.dispatch.tc.qq.com/s0199va6ww6.mp4?vkey=8AD9D3BA3FDC11D69F18657FCFFB8BECBAF8C585B61FCEA680B4D33788C5F9DDA70F79E039A3C62AD11900336BF08B08C9515D8782339A4FF4FCB25A1209663A57AFED21C411A9A1CEED27C536AD3D34650B06E9BD81CF67&br=60&platform=2&fmt=auto&level=0&sdtfrom=v5010","published":1463213905,"weight_new":"0","platform":"1","pic_url":"http://avatar.anzogame.com/pic_v1/lol/news/20160514/spic65727h5736df7a.jpg","recommend":0},{"id":"65726","title":"三少微博宣布 已经加入皇族！","desc":"之前就有人分析三少要去皇族了，没想到是真的\u2026\u2026","video_url":"","published":1463211655,"weight_new":"0","platform":"1","pic_url":"","recommend":0},{"id":"65725","title":"【战报】FW节奏占优扳回一分","desc":"季中邀请赛半决赛CLG vs FW第二场：FW节奏占优扳回一分","video_url":"","published":1463211091,"weight_new":"0","platform":"1","pic_url":"","recommend":0},{"id":"65695","title":"失败亦是英雄 致外卡SUP战队","desc":"在推特上看到了一组SUP粉丝为队员们加油的照片，挺感触的，分享给大家。","video_url":"","published":1463211003,"weight_new":"0","platform":"1","pic_url":"","recommend":0},{"id":"65724","title":"半决赛CLG vs FW 第1场","desc":"2016MSI季中冠军赛半决赛 第2日","video_url":"http://video.dispatch.tc.qq.com/e01998q387r.mp4?vkey=AACC3393C53ABD7F55291094C8362E73D9400948714B8CF05341988314CE1568693A753A3BD80D1A821CB78366230712C49776B9208AB7BD1655DBBA1AD7CDD6427E6452EA37AB0169F632D19F600A0718EFCC8802DBBAB0&br=60&platform=2&fmt=auto&level=0&sdtfrom=v5010","published":1463210250,"weight_new":"0","platform":"1","pic_url":"http://avatar.anzogame.com/pic_v1/lol/news/20160514/spic65724h5736d140.jpg","recommend":0},{"id":"65723","title":"WE中野采访：中野节奏很重要","desc":"Condi预测CLG将3-0进决赛","video_url":"http://video.dispatch.tc.qq.com/y0199rjo80t.mp4?vkey=BC97C8D2788263EA9CAE32625D5D7F471DE4137007DD7CC5C9869D81761CEBA96B20E68262EE48A07F48EF874AA9A6D08F6639AF454DB7AC91F4BEB8E671C1BA1A2244665060AEB2A8FB7257D62D9F92D35CB02FD4750B5D&br=60&platform=2&fmt=auto&level=0&sdtfrom=v5010","published":1463209339,"weight_new":"0","platform":"1","pic_url":"http://avatar.anzogame.com/pic_v1/lol/news/20160514/spic65723h5736cda5.jpg","recommend":0},{"id":"65720","title":"皎月女神 黛安娜的故事","desc":"辣椒看联盟","video_url":"http://k.youku.com/player/getFlvPath/sid/2463210282745205e4650_00/st/mp4/fileid/030020010057354CFEBC0C2D9B7D2FC6BF21B9-AFC6-D028-674E-B67F1C9D0469?k=a9e83104cd17be2524129b0c&hd=1&myp=0&ts=879&r=/3sLngL0Q6CXymAIiF9JUQQtnOFNJPUClO8A56KJJcT8UB+NRAMQ09zE6rNj4EKMxAvRByWf6hitgv75Fv0fffyBqf237nhULGa8oAorPJCAqua0e5BGZ+42RlVI85ARSePd1nzbCM/VeG+AkRPcLw==&ypremium=1&oip=2340490781&token=3696&sid=2463210282745205e4650&did=1463210282&ev=1&ctype=20&ep=bmHRz8upOeh7dlsYm5jdMQWdKeW1Ulmrr6evosLd2vuiUa6Mn%2FDOi9R6znujuzej352nTHUwrZTE9EaUdtF%2F2aNs9TdU8Pp0ke5%2Fc88l1XAF2FIBcZ8uz6BifwLmS1Zc","published":1463209200,"weight_new":"0","platform":"1","pic_url":"http://avatar.anzogame.com/pic_v1/lol/news/20160514/spic65720h57369c72.jpg","recommend":0}]
     * code : 200
     * message : ok
     * api : 1
     */

    private int code;
    private String message;
    private int api;
    /**
     * id : 65721
     * title : 【直播】CLG 2:1 闪电狼
     * desc : MSI季中赛半决赛今日13:30起
     * video_url : http://qqlive.dnion.com:1863/125304401.flv?cdncode=%2f18907E7BE0798990%2f&time=1463201755&cdn=zijian&sdtfrom=v220222&platform=10202&scheduleflag=1&buname=qqlive&vkey=DAC6880BCCC4C2FDCB784445B2CDE1AC022213B823DAC8A19A0AC0D94E860A0D0B45A9C6396B397355ECAB5B1D5FE0E6267522BCF9CA62103331B999F12A2BE9AC5C3DAAEC309A48D8356659F4289E7E464BBF3645FBD850
     * published : 1463197821
     * weight_new : 999
     * platform : 1
     * pic_url : http://avatar.anzogame.com/pic_v1/lol/news/20160514/spic65721h5736b004.jpg
     * recommend : 1
     */

    private List<DataBean> data;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getApi() {
        return api;
    }

    public void setApi(int api) {
        this.api = api;
    }

    public List<DataBean> getData() {
        return data;
    }

    public void setData(List<DataBean> data) {
        this.data = data;
    }

    public static class DataBean {
        private String id;
        private String title;
        private String desc;
        private String video_url;
        private int published;
        private String weight_new;
        private String platform;
        private String pic_url;
        private int recommend;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getDesc() {
            return desc;
        }

        public void setDesc(String desc) {
            this.desc = desc;
        }

        public String getVideo_url() {
            return video_url;
        }

        public void setVideo_url(String video_url) {
            this.video_url = video_url;
        }

        public int getPublished() {
            return published;
        }

        public void setPublished(int published) {
            this.published = published;
        }

        public String getWeight_new() {
            return weight_new;
        }

        public void setWeight_new(String weight_new) {
            this.weight_new = weight_new;
        }

        public String getPlatform() {
            return platform;
        }

        public void setPlatform(String platform) {
            this.platform = platform;
        }

        public String getPic_url() {
            return pic_url;
        }

        public void setPic_url(String pic_url) {
            this.pic_url = pic_url;
        }

        public int getRecommend() {
            return recommend;
        }

        public void setRecommend(int recommend) {
            this.recommend = recommend;
        }
    }
}
