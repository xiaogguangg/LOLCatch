package com.lanou.guan.lolcatch.main.main;

import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.PopupWindow;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.lanou.guan.lolcatch.R;
import com.lanou.guan.lolcatch.main.base.BaseActivity;
import com.lanou.guan.lolcatch.main.base.BaseFragment;
import com.lanou.guan.lolcatch.main.community.CommunityFragment;
import com.lanou.guan.lolcatch.main.hero.HeroFragment;
import com.lanou.guan.lolcatch.main.information.maininformation.InformationFragment;
import com.lanou.guan.lolcatch.main.more.MoreFragment;
import com.lanou.guan.lolcatch.main.video.VideoFragment;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends BaseActivity implements View.OnClickListener{
    private ViewPager mainVP;
    private MainAdapter mainAdapter;
    private RadioGroup radioGroup;
    private List<BaseFragment> fragments;
    private TextView titleTv;
    private ImageButton centerIB;
    private ImageButton changeIB;
    private PopupWindow menuPopup;
    private DrawerLayout mDrawerLayout;
    @Override
    public int initLayout() {
        return R.layout.activity_main;
    }

    @Override
    public void initView() {
        mainVP = (ViewPager) findViewById(R.id.main_vp);
        radioGroup = (RadioGroup) findViewById(R.id.main_rg);
        titleTv = (TextView) findViewById(R.id.title_tv);
        centerIB = (ImageButton) findViewById(R.id.title_center_iv);
        changeIB = (ImageButton) findViewById(R.id.title_change_iv);
        mDrawerLayout = (DrawerLayout) findViewById(R.id.main_drawer);
    }

    @Override
    public void initData() {
        initFragment();
        mainAdapter = new MainAdapter(getSupportFragmentManager());
        mainAdapter.setFragments(fragments);
        mainVP.setAdapter(mainAdapter);
        radioGroup.setOnCheckedChangeListener(new CheckedChangeListener());
        mainVP.setOnPageChangeListener(new PageChangeListener());
        setTitleBar(0);
        centerIB.setOnClickListener(this);

    }

    private void initFragment() {
        fragments = new ArrayList<>();
        fragments.add(new InformationFragment());
        fragments.add(new VideoFragment());
        fragments.add(new HeroFragment());
        fragments.add(new CommunityFragment());
        fragments.add(new MoreFragment());
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.title_center_iv:
                mDrawerLayout.openDrawer(Gravity.LEFT);
                break;
        }
    }

    private class CheckedChangeListener implements RadioGroup.OnCheckedChangeListener {
        @Override
        public void onCheckedChanged(RadioGroup group, int checkedId) {
            switch (checkedId) {
                case R.id.information_rb:
                    mainVP.setCurrentItem(0);
                    break;
                case R.id.video_rb:
                    mainVP.setCurrentItem(1);
                    break;
                case R.id.hero_rb:
                    mainVP.setCurrentItem(2);
                    break;
                case R.id.community_rb:
                    mainVP.setCurrentItem(3);
                    break;
                case R.id.more_rb:
                    mainVP.setCurrentItem(4);
            }
        }
    }
    private class PageChangeListener implements ViewPager.OnPageChangeListener {
        @Override
        public void onPageSelected(int position) {
            switch (position) {
                case 0:
                    radioGroup.check(R.id.information_rb);
                    break;
                case 1:
                    radioGroup.check(R.id.video_rb);
                    break;
                case 2:
                    radioGroup.check(R.id.hero_rb);
                    break;
                case 3:
                    radioGroup.check(R.id.community_rb);
                    break;
                case 4:
                    radioGroup.check(R.id.more_rb);
                    break;
            }

        }

        @Override
        public void onPageScrollStateChanged(int arg0) {
            setTitleBar(arg0);
        }

        @Override
        public void onPageScrolled(int arg0, float arg1, int arg2) {
            if(menuPopup != null){
                menuPopup.dismiss();
            }
        }
    }
    private void setTitleBar(int pos){
        titleTv.setText(mainAdapter.getPageTitle(pos));
        switch (pos){
            case 0:
                changeIB.setVisibility(View.VISIBLE);
                break;
            case 1:
                break;
            case 2:
                changeIB.setVisibility(View.GONE);
                break;
            case 3:
                changeIB.setVisibility(View.GONE);
                break;
            case 4:
                changeIB.setVisibility(View.GONE);
                break;
        }
    }

}
