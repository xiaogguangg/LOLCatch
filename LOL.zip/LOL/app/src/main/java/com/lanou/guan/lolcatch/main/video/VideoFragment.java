package com.lanou.guan.lolcatch.main.video;

import android.view.View;

import com.lanou.guan.lolcatch.R;
import com.lanou.guan.lolcatch.main.base.BaseFragment;

/**
 * Created by dllo on 16/5/14.
 */
public class VideoFragment extends BaseFragment {
    @Override
    protected int setLayout() {
        return R.layout.fragment_video;
    }

    @Override
    protected void initView(View view) {

    }

    @Override
    protected void initData() {

    }
}
